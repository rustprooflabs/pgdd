--
-- sql/lib.generated.sql
--
COMMENT ON SCHEMA dd IS 'Data Dictionary from https://github.com/rustprooflabs/pgdd';

CREATE TABLE dd.meta_schema
(
    meta_schema_id SERIAL NOT NULL,
    s_name name NOT NULL,
    data_source TEXT NULL,
    sensitive BOOLEAN NOT NULL,
    CONSTRAINT PK_dd_meta_schema_id PRIMARY KEY (meta_schema_id),
    CONSTRAINT UQ_dd_meta_schema_name UNIQUE (s_name)
);

COMMENT ON TABLE dd.meta_schema 
    IS 'User definable meta-data at the schema level.'
;

COMMENT ON COLUMN dd.meta_schema.s_name
    IS 'Schema name.'
;

INSERT INTO dd.meta_schema (s_name, data_source, sensitive)
    VALUES ('dd', 'Manually maintained', False);

CREATE TABLE dd.meta_table
(
    meta_table_id SERIAL NOT NULL,
    s_name name NOT NULL,
    t_name name NOT NULL,
    data_source TEXT NULL,
    sensitive BOOLEAN NOT NULL DEFAULT False,
    CONSTRAINT PK_dd_meta_table_id PRIMARY KEY (meta_table_id),
    CONSTRAINT UQ_dd_meta_table_schema_table UNIQUE (s_name, t_name)
);


COMMENT ON TABLE dd.meta_table 
    IS 'User definable meta-data at the schema + table level.'
;


CREATE TABLE dd.meta_column
(
    meta_column_id SERIAL NOT NULL,
    s_name name NOT NULL,
    t_name name NOT NULL,
    c_name name NOT NULL,
    data_source TEXT NULL,
    sensitive BOOLEAN NOT NULL DEFAULT False,
    CONSTRAINT PK_dd_meta_column_id PRIMARY KEY (meta_column_id),
    CONSTRAINT UQ_dd_meta_column_schema_table_column UNIQUE (s_name, t_name, c_name)
);


COMMENT ON TABLE dd.meta_column 
    IS 'User definable meta-data at the schema + table + column level.'
;


INSERT INTO dd.meta_table (s_name, t_name, data_source, sensitive)
    VALUES ('dd', 'meta_schema', 'Manually maintained', False);
INSERT INTO dd.meta_table (s_name, t_name, data_source, sensitive)
    VALUES ('dd', 'meta_table', 'Manually maintained', False);
INSERT INTO dd.meta_table (s_name, t_name, data_source, sensitive)
    VALUES ('dd', 'meta_column', 'Manually maintained', False);




COMMENT ON COLUMN dd.meta_column.sensitive
    IS 'Indicates if the column stores sensitive data.'
;

INSERT INTO dd.meta_column (s_name, t_name, c_name, data_source, sensitive)
    VALUES ('dd', 'meta_column', 'sensitive', 'Manually defined', False)
;
-- ./src/lib.rs:87:0
CREATE OR REPLACE FUNCTION dd."schemas"() RETURNS TABLE ("s_name" text, "owner" text, "data_source" text, "sensitive" bool, "description" text, "system_object" bool, "table_count" bigint, "view_count" bigint, "function_count" bigint, "size_pretty" text, "size_plus_indexes" text, "size_bytes" bigint) STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'schemas_wrapper';
-- ./src/lib.rs:121:0
CREATE OR REPLACE FUNCTION dd."columns"() RETURNS TABLE ("s_name" text, "source_type" text, "t_name" text, "c_name" text, "data_type" text, "position" bigint, "description" text, "data_source" text, "sensitive" bool, "system_object" bool, "default_value" text, "generated_column" bool) STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'columns_wrapper';
-- ./src/lib.rs:159:0
CREATE OR REPLACE FUNCTION dd."functions"() RETURNS TABLE ("s_name" text, "f_name" text, "result_data_types" text, "argument_data_types" text, "owned_by" text, "proc_security" text, "access_privileges" text, "proc_language" text, "source_code" text, "description" text, "system_object" bool) STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'functions_wrapper';
-- ./src/lib.rs:194:0
CREATE OR REPLACE FUNCTION dd."tables"() RETURNS TABLE ("s_name" text, "t_name" text, "type" text, "owned_by" text, "size_pretty" text, "size_bytes" bigint, "rows" bigint, "bytes_per_row" bigint, "size_plus_indexes" text, "description" text, "system_object" bool, "data_source" text, "sensitive" bool) STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'tables_wrapper';
-- ./src/lib.rs:232:0
CREATE OR REPLACE FUNCTION dd."views"() RETURNS TABLE ("s_name" text, "v_name" text, "view_type" text, "owned_by" text, "rows" bigint, "size_pretty" text, "size_bytes" bigint, "description" text, "system_object" bool) STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'views_wrapper';
-- ./src/lib.rs:263:0
CREATE OR REPLACE FUNCTION dd."about"() RETURNS text STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'about_wrapper';
-- ./src/lib.rs:268:0
CREATE OR REPLACE FUNCTION dd."version"() RETURNS text STRICT LANGUAGE c AS 'MODULE_PATHNAME', 'version_wrapper';



